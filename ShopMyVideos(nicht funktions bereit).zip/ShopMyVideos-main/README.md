# ShopMyVideos

Ein Webshop-System für den Verkauf und Upload von Videos mit Admin- und Creator-Bereich.

## Features

- User- und Admin-Authentifizierung
- Video-Upload & Vorschau
- Gutschein-System
- Supportnachrichten
- Creator-Dashboard & Admin-Panel

## Setup

```bash
git clone <repo-url>
cd shopmyvideos
npm install
