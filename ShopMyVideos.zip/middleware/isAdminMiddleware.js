
module.exports = (req, res, next) => {
    const { userId } = req;
    // Logic to check if the user is an admin
    if (userId !== 1) { // Placeholder check for admin status
        return res.status(403).json({ message: 'Not an admin' });
    }
    next();
};
    