
module.exports = (req, res, next) => {
    const { userId } = req;
    // Logic to check if the user is a creator
    if (userId !== 1) { // Placeholder check for creator status
        return res.status(403).json({ message: 'Not a creator' });
    }
    next();
};
    