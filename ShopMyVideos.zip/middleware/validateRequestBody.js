
module.exports = (req, res, next) => {
    const { title, price } = req.body;
    if (!title || !price) {
        return res.status(400).json({ message: 'Title and price are required' });
    }
    next();
};
    