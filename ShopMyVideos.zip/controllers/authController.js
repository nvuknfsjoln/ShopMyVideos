
const jwt = require('jsonwebtoken');

exports.login = (req, res) => {
    const { username, password } = req.body;
    // Logic for user login
    res.json({ message: 'Login successful' });
};

exports.register = (req, res) => {
    const { username, password } = req.body;
    // Logic for user registration
    res.json({ message: 'Registration successful' });
};
    