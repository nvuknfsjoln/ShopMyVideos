
const Creator = require('../models/Creator');

exports.createCreator = (req, res) => {
    const { name, email } = req.body;
    // Logic to create a new creator
    res.json({ message: 'Creator created successfully' });
};

exports.getCreator = (req, res) => {
    const creatorId = req.params.id;
    // Logic to fetch a creator
    res.json({ message: `Creator with id ${creatorId} fetched` });
};
    