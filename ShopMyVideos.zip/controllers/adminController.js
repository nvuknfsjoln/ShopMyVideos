
const Admin = require('../models/Admin');

exports.createAdmin = (req, res) => {
    const { username, password } = req.body;
    // Logic to create a new admin
    res.json({ message: 'Admin created successfully' });
};

exports.deleteAdmin = (req, res) => {
    const adminId = req.params.id;
    // Logic to delete an admin
    res.json({ message: `Admin with id ${adminId} deleted` });
};
    